# Fame Browser - all devices

| Device | Folder | How to run |
|---|---|---|
| Laptop (Windows / Mac / Linux) | `laptop-windows-mac-linux/` | Install Node.js, then `npm install` and `npm start`. For VPN install WireGuard and run as administrator. |
| Android phone | `phone-android/` | Build the APK online: upload everything to GitHub, Actions > Build APK > Run workflow. Or open `phone-android` in Android Studio. |
| Any device (limited) | `web-pwa/` | Host the folder (Netlify Drop / GitHub Pages), open in Chrome, Install app. Some sites will not load inside it. |

iPhone/iPad: not supported by these files (needs Xcode and a Mac).
No account or Gmail sign-in is needed anywhere. The app saves no history. Ad blocker is off by default.
