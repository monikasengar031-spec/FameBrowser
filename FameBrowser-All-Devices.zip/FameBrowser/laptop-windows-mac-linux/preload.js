const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('vpn', {
  save: (text) => ipcRenderer.invoke('vpn:save', text),
  load: () => ipcRenderer.invoke('vpn:load'),
  up: () => ipcRenderer.invoke('vpn:up'),
  down: () => ipcRenderer.invoke('vpn:down'),
});

contextBridge.exposeInMainWorld('ads', {
  toggle: () => ipcRenderer.invoke('ads:toggle'),
  count: () => ipcRenderer.invoke('ads:count'),
});
