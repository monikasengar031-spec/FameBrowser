const { app, BrowserWindow, ipcMain, session } = require('electron');
const { isBlocked } = require('./adblock');

let adblockOn = false; // ad blocker off by default (toggle with the Ads button)
let blockedCount = 0;
const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');

const TUNNEL_NAME = 'securebrowser';
let win;

function confPath() {
  return path.join(app.getPath('userData'), TUNNEL_NAME + '.conf');
}

function createWindow() {
  win = new BrowserWindow({
    title: 'Fame Browser',
    width: 1200,
    height: 800,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      webviewTag: true,
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.loadFile('index.html');
}

// Run wireguard tools. On Windows this uses wireguard.exe tunnel service,
// on Linux/macOS it uses wg-quick. Needs administrator / sudo rights.
function runWg(action) {
  return new Promise((resolve) => {
    const conf = confPath();
    if (!fs.existsSync(conf)) {
      return resolve({ ok: false, message: 'Save a WireGuard config first.' });
    }
    let cmd, args;
    if (process.platform === 'win32') {
      cmd = 'wireguard.exe';
      args = action === 'up' ? ['/installtunnelservice', conf] : ['/uninstalltunnelservice', TUNNEL_NAME];
    } else {
      cmd = 'wg-quick';
      args = [action, conf];
    }
    execFile(cmd, args, (err, stdout, stderr) => {
      if (err) {
        resolve({
          ok: false,
          message: (stderr || err.message) + '\nTip: install WireGuard and run this app as administrator (sudo on Linux/macOS).',
        });
      } else {
        resolve({ ok: true, message: action === 'up' ? 'VPN connected' : 'VPN disconnected' });
      }
    });
  });
}

ipcMain.handle('vpn:save', async (_e, text) => {
  try {
    fs.writeFileSync(confPath(), text, { mode: 0o600 });
    return { ok: true, message: 'Config saved.' };
  } catch (e) {
    return { ok: false, message: e.message };
  }
});
ipcMain.handle('vpn:load', async () => (fs.existsSync(confPath()) ? fs.readFileSync(confPath(), 'utf8') : ''));
ipcMain.handle('vpn:up', () => runWg('up'));
ipcMain.handle('vpn:down', () => runWg('down'));

ipcMain.handle('ads:toggle', () => {
  adblockOn = !adblockOn;
  return { on: adblockOn, count: blockedCount };
});
ipcMain.handle('ads:count', () => ({ on: adblockOn, count: blockedCount }));

app.whenReady().then(() => {
  // 'private-session' (no "persist:" prefix) is an in-memory session: no history, cookies
  // or cache are ever written to disk. Must match the webview partition in index.html.
  const ses = session.fromPartition('private-session');
  ses.webRequest.onBeforeRequest({ urls: ['<all_urls>'] }, (details, callback) => {
    if (adblockOn && isBlocked(details.url)) {
      blockedCount++;
      return callback({ cancel: true });
    }
    callback({});
  });
  createWindow();
});

app.on('window-all-closed', async () => {
  try {
    const ses = session.fromPartition('private-session');
    await ses.clearStorageData();
    await ses.clearCache();
  } catch (e) {}
  app.quit();
});
