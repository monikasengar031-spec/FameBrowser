// Simple domain-based ad/tracker blocklist. Add more domains as you like.
const BLOCKED = [
  'doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'adservice.google.com',
  'google-analytics.com', 'googletagmanager.com', 'googletagservices.com', 'adnxs.com',
  'taboola.com', 'outbrain.com', 'criteo.com', 'criteo.net', 'pubmatic.com', 'rubiconproject.com',
  'openx.net', 'adsrvr.org', 'amazon-adsystem.com', 'scorecardresearch.com', 'hotjar.com',
  'moatads.com', 'advertising.com', 'popads.net', 'propellerads.com', 'exoclick.com',
  'mgid.com', 'adform.net', 'casalemedia.com', 'smartadserver.com', 'yieldmo.com',
  'quantserve.com', 'ads.yahoo.com', 'adcolony.com', 'unityads.unity3d.com', 'ads.twitter.com',
];

function isBlocked(url) {
  try {
    const host = new URL(url).hostname;
    return BLOCKED.some((d) => host === d || host.endsWith('.' + d));
  } catch (e) {
    return false;
  }
}

module.exports = { isBlocked };
