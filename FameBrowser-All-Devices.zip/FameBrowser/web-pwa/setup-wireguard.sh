#!/usr/bin/env bash
# One-shot WireGuard VPN server setup for Ubuntu/Debian VPS.
#
# Usage (run on your VPS as root):
#   sudo bash setup-wireguard.sh            # install server + create client "phone"
#   sudo bash setup-wireguard.sh add laptop # add another client later
#
# Client configs are saved in /etc/wireguard/clients/NAME.conf
# A QR code is printed so you can scan it with the WireGuard mobile app.

set -euo pipefail

WG_IF="wg0"
WG_PORT="51820"
WG_NET="10.8.0"          # server = 10.8.0.1, clients start at 10.8.0.2
DNS="1.1.1.1, 1.0.0.1"
WG_DIR="/etc/wireguard"
CLIENT_DIR="$WG_DIR/clients"

if [[ $EUID -ne 0 ]]; then
  echo "Please run as root: sudo bash $0" >&2
  exit 1
fi

add_client() {
  local name="$1"
  if [[ ! "$name" =~ ^[A-Za-z0-9_-]+$ ]]; then
    echo "Client name may only contain letters, numbers, - and _" >&2
    exit 1
  fi
  if [[ -f "$CLIENT_DIR/$name.conf" ]]; then
    echo "Client '$name' already exists: $CLIENT_DIR/$name.conf" >&2
    exit 1
  fi

  mkdir -p "$CLIENT_DIR"
  umask 077

  local count next_ip
  count=$(grep -c '^\[Peer\]' "$WG_DIR/$WG_IF.conf" || true)
  next_ip="$WG_NET.$((count + 2))"

  local c_priv c_pub psk s_pub endpoint
  c_priv=$(wg genkey)
  c_pub=$(echo "$c_priv" | wg pubkey)
  psk=$(wg genpsk)
  s_pub=$(cat "$WG_DIR/server.pub")
  endpoint=$(cat "$WG_DIR/endpoint")

  cat >> "$WG_DIR/$WG_IF.conf" <<EOF

# client: $name
[Peer]
PublicKey = $c_pub
PresharedKey = $psk
AllowedIPs = $next_ip/32
EOF

  cat > "$CLIENT_DIR/$name.conf" <<EOF
[Interface]
PrivateKey = $c_priv
Address = $next_ip/24
DNS = $DNS

[Peer]
PublicKey = $s_pub
PresharedKey = $psk
Endpoint = $endpoint:$WG_PORT
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
EOF

  # Apply new peer without dropping existing connections
  if ip link show "$WG_IF" >/dev/null 2>&1; then
    wg syncconf "$WG_IF" <(wg-quick strip "$WG_IF")
  fi

  echo
  echo "Client '$name' created: $CLIENT_DIR/$name.conf  (VPN IP $next_ip)"
  if command -v qrencode >/dev/null; then
    echo "Scan this QR code with the WireGuard app:"
    qrencode -t ansiutf8 < "$CLIENT_DIR/$name.conf"
  fi
}

# --- "add" mode -------------------------------------------------------------
if [[ "${1:-}" == "add" ]]; then
  [[ -f "$WG_DIR/$WG_IF.conf" ]] || { echo "Server not set up yet. Run without arguments first." >&2; exit 1; }
  add_client "${2:?Usage: $0 add CLIENT_NAME}"
  exit 0
fi

# --- Full install -----------------------------------------------------------
if [[ -f "$WG_DIR/$WG_IF.conf" ]]; then
  echo "$WG_DIR/$WG_IF.conf already exists. Use '$0 add NAME' to add clients." >&2
  exit 1
fi

echo "==> Installing packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y wireguard qrencode curl iptables

echo "==> Detecting network settings"
NIC=$(ip -4 route show default | awk '{print $5; exit}')
PUBLIC_IP=$(curl -4 -fsS --max-time 10 https://ifconfig.me || true)
if [[ -z "$NIC" ]]; then echo "Could not detect default network interface." >&2; exit 1; fi
if [[ -z "$PUBLIC_IP" ]]; then
  read -rp "Could not detect public IP. Enter server public IP or domain: " PUBLIC_IP
fi
echo "    interface: $NIC   public IP: $PUBLIC_IP"

echo "==> Enabling IP forwarding"
echo "net.ipv4.ip_forward=1" > /etc/sysctl.d/99-wireguard.conf
sysctl --system >/dev/null

echo "==> Generating server keys"
umask 077
mkdir -p "$WG_DIR"
wg genkey | tee "$WG_DIR/server.key" | wg pubkey > "$WG_DIR/server.pub"
echo "$PUBLIC_IP" > "$WG_DIR/endpoint"

cat > "$WG_DIR/$WG_IF.conf" <<EOF
[Interface]
Address = $WG_NET.1/24
ListenPort = $WG_PORT
PrivateKey = $(cat "$WG_DIR/server.key")
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -s $WG_NET.0/24 -o $NIC -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -s $WG_NET.0/24 -o $NIC -j MASQUERADE
EOF

echo "==> Opening firewall (UDP $WG_PORT)"
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow "$WG_PORT/udp"
  # ufw drops forwarded traffic by default; allow it for the VPN subnet
  sed -i 's/^DEFAULT_FORWARD_POLICY=.*/DEFAULT_FORWARD_POLICY="ACCEPT"/' /etc/default/ufw
  ufw reload
fi

echo "==> Starting WireGuard"
systemctl enable --now "wg-quick@$WG_IF"

add_client "${1:-phone}"

cat <<EOF

=====================================================================
VPN server is running on UDP port $WG_PORT.

IMPORTANT: also open UDP $WG_PORT in your cloud provider's firewall /
security group (AWS, GCP, Oracle, DigitalOcean etc.) if it has one.

Add more devices:   sudo bash $0 add laptop
Check status:       sudo wg show
=====================================================================
EOF
