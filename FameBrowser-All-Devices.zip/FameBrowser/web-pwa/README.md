# Fame Browser + WireGuard

- `index.html` – Fame Browser (open in any browser or wrap with html2app). The VPN panel can import/save a WireGuard client `.conf` and download the server setup script.
- `setup-wireguard.sh` – run on an Ubuntu/Debian VPS: `sudo bash setup-wireguard.sh` (creates client "phone"), `sudo bash setup-wireguard.sh add laptop` for more.

Flow: run the script on the VPS -> take `/etc/wireguard/clients/NAME.conf` -> import it in the browser panel (stored in localStorage) or load it in the WireGuard app.
Note: a web page cannot create a real VPN tunnel; use the WireGuard app/desktop client for the actual connection.

## Install as an app from Chrome (PWA)
Host this whole folder on any free static host (e.g. Netlify Drop, GitHub Pages). Open the https link in Chrome on Android, then menu (⋮) > **Install app** / **Add to Home screen**. The icon opens Fame Browser in Chrome's engine as an app.
