package com.example.securebrowser

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var urlBar: EditText
    private lateinit var progress: ProgressBar
    private lateinit var btnVpn: Button
    private lateinit var vpn: VpnManager

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) startTunnel()
            else toast("VPN permission denied")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        vpn = VpnManager(applicationContext)
        webView = findViewById(R.id.webview)
        urlBar = findViewById(R.id.urlBar)
        progress = findViewById(R.id.progress)
        btnVpn = findViewById(R.id.btnVpn)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        // Private mode: no cache, no saved form data, no cookies kept
        webView.settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        webView.settings.saveFormData = false
        android.webkit.CookieManager.getInstance().removeAllCookies(null)
        webView.webViewClient = object : WebViewClient() {
            // Ad blocker: return an empty response for blocked ad/tracker domains.
            override fun shouldInterceptRequest(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): android.webkit.WebResourceResponse? {
                return if (AdBlocker.isBlocked(request.url)) {
                    android.webkit.WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                } else super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                urlBar.setText(url)
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) android.view.View.VISIBLE else android.view.View.GONE
            }
        }

        urlBar.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                (event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                webView.loadUrl(normalize(urlBar.text.toString()))
                true
            } else false
        }
        findViewById<ImageButton>(R.id.btnBack).setOnClickListener {
            if (webView.canGoBack()) webView.goBack()
        }
        btnVpn.setOnClickListener { showVpnDialog() }

        webView.loadUrl("https://duckduckgo.com/")
    }

    private fun normalize(q: String): String {
        val t = q.trim()
        if (t.isEmpty()) return "https://duckduckgo.com/"
        if (t.startsWith("http://") || t.startsWith("https://")) return t
        if (!t.contains(' ') && Regex("^[\\w-]+(\\.[\\w-]+)+(/.*)?$").matches(t)) return "https://$t"
        return "https://duckduckgo.com/?q=" + Uri.encode(t)
    }

    private fun showVpnDialog() {
        val input = EditText(this).apply {
            setText(vpn.savedConfig())
            hint = "[Interface]\nPrivateKey = ...\nAddress = 10.0.0.2/32\n\n[Peer]\nPublicKey = ...\nEndpoint = host:51820\nAllowedIPs = 0.0.0.0/0"
            minLines = 8
            textSize = 12f
        }
        val up = vpn.isUp()
        AlertDialog.Builder(this)
            .setTitle("WireGuard VPN")
            .setMessage("Paste your WireGuard config. No account needed.")
            .setView(input)
            .setPositiveButton(if (up) "Save" else "Save & Connect") { _, _ ->
                vpn.saveConfig(input.text.toString())
                if (!up) connectWithPermission()
            }
            .setNeutralButton(if (up) "Disconnect" else "Cancel") { _, _ ->
                if (up) stopTunnel()
            }
            .show()
    }

    private fun connectWithPermission() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else startTunnel()
    }

    private fun startTunnel() {
        thread {
            try {
                vpn.connect()
                runOnUiThread { setVpnUi(true); toast("VPN connected") }
            } catch (e: Exception) {
                runOnUiThread { toast("VPN error: ${e.message}") }
            }
        }
    }

    private fun stopTunnel() {
        thread {
            try {
                vpn.disconnect()
                runOnUiThread { setVpnUi(false); toast("VPN disconnected") }
            } catch (e: Exception) {
                runOnUiThread { toast("VPN error: ${e.message}") }
            }
        }
    }

    private fun setVpnUi(on: Boolean) {
        btnVpn.text = if (on) "VPN: On" else "VPN: Off"
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun wipeBrowsingData() {
        webView.clearHistory()
        webView.clearCache(true)
        webView.clearFormData()
        android.webkit.WebStorage.getInstance().deleteAllData()
        android.webkit.CookieManager.getInstance().removeAllCookies(null)
        android.webkit.CookieManager.getInstance().flush()
    }

    override fun onStop() {
        super.onStop()
        wipeBrowsingData()
    }

    override fun onDestroy() {
        wipeBrowsingData()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
