package com.example.securebrowser

import android.net.Uri

/** Simple domain-based ad/tracker blocklist. Add more domains as you like. */
object AdBlocker {
    var enabled = false
    var blockedCount = 0

    private val blocked = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "google-analytics.com", "googletagmanager.com", "googletagservices.com", "adnxs.com",
        "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "pubmatic.com", "rubiconproject.com",
        "openx.net", "adsrvr.org", "amazon-adsystem.com", "scorecardresearch.com", "hotjar.com",
        "moatads.com", "advertising.com", "popads.net", "propellerads.com", "exoclick.com",
        "mgid.com", "adform.net", "casalemedia.com", "smartadserver.com", "yieldmo.com",
        "quantserve.com", "ads.yahoo.com", "adcolony.com", "unityads.unity3d.com", "ads.twitter.com"
    )

    fun isBlocked(url: Uri): Boolean {
        if (!enabled) return false
        val host = url.host ?: return false
        val hit = blocked.any { host == it || host.endsWith(".$it") }
        if (hit) blockedCount++
        return hit
    }
}
