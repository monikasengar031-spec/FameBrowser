package com.example.securebrowser

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import java.io.ByteArrayInputStream

/**
 * Wraps the official WireGuard GoBackend.
 * The config text is stored privately in the app's own storage. No account is needed.
 */
class VpnManager(private val context: Context) {

    private val backend = GoBackend(context)
    private val prefs = context.getSharedPreferences("vpn", Context.MODE_PRIVATE)

    private val tunnel = object : Tunnel {
        override fun getName() = "securebrowser"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    fun savedConfig(): String = prefs.getString("conf", "") ?: ""

    fun saveConfig(text: String) {
        prefs.edit().putString("conf", text).apply()
    }

    fun isUp(): Boolean = backend.getState(tunnel) == Tunnel.State.UP

    /** Call only after VpnService.prepare() permission was granted. */
    fun connect() {
        val text = savedConfig()
        require(text.isNotBlank()) { "Paste a WireGuard config first." }
        val config = Config.parse(ByteArrayInputStream(text.toByteArray()))
        backend.setState(tunnel, Tunnel.State.UP, config)
    }

    fun disconnect() {
        backend.setState(tunnel, Tunnel.State.DOWN, null)
    }
}
